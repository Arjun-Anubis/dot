"""
Module containing the OWMError class as base for all other OWM errors
"""


class OWMError(Exception):
    pass

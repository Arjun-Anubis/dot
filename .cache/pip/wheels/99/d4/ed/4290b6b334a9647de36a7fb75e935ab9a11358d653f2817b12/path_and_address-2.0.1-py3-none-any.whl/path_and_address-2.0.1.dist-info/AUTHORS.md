Authors
=======

[Path-and-address][home] is written and maintained by Joe Esposito,
along with the following contributors:

- Tiago Ilieve ([@myhro](https://github.com/myhro))

[home]: README.md

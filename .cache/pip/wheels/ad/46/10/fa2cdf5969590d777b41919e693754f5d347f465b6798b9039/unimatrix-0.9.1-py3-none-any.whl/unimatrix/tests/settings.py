# Test settings module
BAR = 2

HTTP_CORS_TTL = 123
